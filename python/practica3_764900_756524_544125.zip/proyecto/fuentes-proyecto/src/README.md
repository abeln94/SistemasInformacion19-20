# Comandos y explicaciones:

Nota: De momento por comodidad el servicio incluye por defecto 4 tipos de vehículos y un superusuario (nombre=user, contraseña=user) con el que poder acceder a la página de administración '/admin'

## Instalar/Iniciar
- El sistema está implementado como docker-compose, basta lanzar ```docker-compose up``` (por comodidad se proporciona el script ```rundocker``` que ejecuta exactamente eso)

### Añadir superusuario
- En caso de querer añadir otro superusuario de momento se debe hacer por comando ```python migrate.py createsuperuser``` y meter los datos segun va preguntando
